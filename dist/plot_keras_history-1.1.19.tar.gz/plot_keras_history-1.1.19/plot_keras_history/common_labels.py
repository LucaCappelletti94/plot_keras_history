common_labels = {
    "Learning rate":["lr"],
    "Accuracy":["acc", "accuracy"],
    "Loss":["loss"],
    "AUPRC":["auprc"],
    "AUROC":["auroc"]
}