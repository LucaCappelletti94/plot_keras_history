"""Current version of package plot_keras_history"""
__version__ = "1.1.23"