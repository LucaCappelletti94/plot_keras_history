"""Current version of package."""
__version__ = "1.1.5"