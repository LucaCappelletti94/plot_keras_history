common_labels = {
    "Learning rate":["lr"]
}