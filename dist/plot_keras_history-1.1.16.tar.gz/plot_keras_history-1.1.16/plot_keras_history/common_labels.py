common_labels = {
    "Learning rate":["lr"],
    "Accuracy":["acc"],
    "Loss":["loss"],
    "AUPRC":["auprc"],
    "AUROC":["auroc"]
}